(function ($) {
	var items = [];

	function render(props) {
		return function (tok, i) {
			return (i % 2) ? props[tok] : tok;
		};
	}

	function showResult(href) {
		var param = document.getElementById('search-param');
		$.ajax({
			type: 'GET',
			url: href + '?query=' + param.value,
			success: function (data) {
				this.items = [];
				this.items = data.rows;
				if (this.items.length > 0) {

					$('#searchresult-found').show();
					$('#searchresult').hide();
					$('.list-items').empty()
					var itemTpl = $('script[data-template="listitem"]').text().split(/\{\{(.+?)\}\}/g);

					$('.list-items').append(this.items.map(function (item) {
						return itemTpl.map(render(item)).join('');
					}));
				} else {
					$('#searchresult-found').hide();
					$('#searchresult').show();


				}
			},
			error: function (XMLHttpRequest, textStatus, errorThrown) {
				try {
					if (p.onError) p.onError(XMLHttpRequest, textStatus, errorThrown);
				} catch (e) {}
			}
		});
	}
	jQuery(document).on("click", "#search-page-button", function (e) {
		e.preventDefault();
		showResult($(this).data('href'));
	});

})(jQuery);